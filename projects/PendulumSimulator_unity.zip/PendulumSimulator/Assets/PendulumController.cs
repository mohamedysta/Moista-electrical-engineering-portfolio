﻿using UnityEngine;
using UnityEngine.UI;

public class PendulumController : MonoBehaviour 
{
	public Rigidbody bob;
	public Text infoText;
	public float releaseAngle = 45f;

	private bool released = false;
	private Vector3 startPos;

	void Start() 
	{
		startPos = bob.transform.position;
		// Start at angle
		bob.transform.position = new Vector3(
			Mathf.Sin(releaseAngle * Mathf.Deg2Rad) * 3f,
			5f - Mathf.Cos(releaseAngle * Mathf.Deg2Rad) * 3f,
			0
		);
		bob.isKinematic = true; // Hold in place
	}

	void Update() 
	{
		// Release on spacebar
		if (Input.GetKeyDown(KeyCode.Space) && !released) 
		{
			bob.isKinematic = false;
			released = true;
			infoText.text = "Pendulum Released - Observe Energy Transfer";
		}

		// Reset on R
		if (Input.GetKeyDown(KeyCode.R)) 
		{
			ResetPendulum();
		}

		// Show velocity
		if (released) 
		{
			float speed = bob.velocity.magnitude;
			infoText.text = "Velocity: " + speed.ToString("F2") + " m/s";
		}
	}

	void ResetPendulum() 
	{
		released = false;
		bob.isKinematic = true;
		bob.velocity = Vector3.zero;
		bob.angularVelocity = Vector3.zero;
		Start();
		infoText.text = "Press SPACE to release";
	}
}
